.. _API ControlFunction:

ControlFunction API
===================

.. doxygenclass:: isobus::ControlFunction
   :members: