Transport Protocol API
======================

.. doxygenfunction:: isobus::CANNetworkManager::get_active_transport_protocol_sessions

.. doxygenclass:: isobus::TransportProtocolSessionBase
   :members: