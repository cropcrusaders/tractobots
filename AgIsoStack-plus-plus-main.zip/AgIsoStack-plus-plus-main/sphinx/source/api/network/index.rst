Network API
===========

This is the core of the library to compliantly communicate on the ISOBUS network.

It provides the following, but not limited to:

.. toctree::
   :maxdepth: 1
   :titlesonly:

   control functions
   transport protocols