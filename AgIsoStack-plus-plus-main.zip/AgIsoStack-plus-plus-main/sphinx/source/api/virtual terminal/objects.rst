Object Definitions
==================

.. doxygenfile:: isobus/isobus/isobus_virtual_terminal_objects.hpp
