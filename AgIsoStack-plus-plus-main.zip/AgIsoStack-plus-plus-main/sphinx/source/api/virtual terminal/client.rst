.. _API VirtualTerminalClient:

Client API
==========

.. doxygenclass:: isobus::VirtualTerminalClient
   :members: