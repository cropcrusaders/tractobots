.. _API SpeedDistance:

Speed and Distance API
======================

This is a collection of classes for processing and sending ISOBUS speed messages.

.. doxygenclass:: isobus::SpeedMessagesInterface
   :members:
